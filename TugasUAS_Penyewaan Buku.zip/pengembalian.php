<?php 
	require('cek_session.php');
	halamanAdmin();
?>